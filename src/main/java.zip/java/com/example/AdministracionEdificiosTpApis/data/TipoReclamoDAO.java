package com.example.AdministracionEdificiosTpApis.data;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.AdministracionEdificiosTpApis.model.TipoReclamo;

@Repository
public class TipoReclamoDAO {
	
	//-------------REPOSITORIO-------------
	
    @Autowired
    private TipoReclamoRepository tipoReclamoRepository;
	
	//-------------CRUD-------------
	
    public void agregarTipoReclamo(TipoReclamo tipoReclamo) {
        tipoReclamoRepository.save(tipoReclamo);
    }

    public void actualizarTipoReclamo(TipoReclamo tipoReclamo) {
        tipoReclamoRepository.save(tipoReclamo);
    }

    public void eliminarTipoReclamo(int idTipoReclamo) {
        tipoReclamoRepository.deleteById(idTipoReclamo);
    }
    
	//-------------METODOS-------------

    public List<TipoReclamo> getAllTiposReclamos() {
        return tipoReclamoRepository.findAll();
    }

    public Optional<TipoReclamo> getTipoReclamoById(int id) {
        return tipoReclamoRepository.findById(id);
    }
}
