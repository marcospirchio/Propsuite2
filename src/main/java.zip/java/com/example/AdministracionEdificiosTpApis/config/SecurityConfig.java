package com.example.AdministracionEdificiosTpApis.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.example.AdministracionEdificiosTpApis.security.JwtAuthenticationEntryPoint;
import com.example.AdministracionEdificiosTpApis.security.JwtRequestFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http,
                                           JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint,
                                           JwtRequestFilter jwtRequestFilter) throws Exception {
        http
            .csrf().disable()
            .authorizeHttpRequests(auth -> auth
                // Rutas públicas
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers("/api/usuario/restablecerContrasena").permitAll()

                // Rutas protegidas - Reclamos
                .requestMatchers("/api/reclamos/mis-reclamos").hasAuthority("USUARIO")
                .requestMatchers("/api/reclamos/sinUnidad").hasAuthority("USUARIO")
                .requestMatchers("/api/reclamos/conUnidad").hasAuthority("USUARIO")
                .requestMatchers("/api/reclamos/areas-comunes").hasAuthority("USUARIO")
                .requestMatchers("/api/reclamos").hasAuthority("ADMIN")
                .requestMatchers("/api/reclamos/**").hasAuthority("ADMIN")
            	
                // Rutas protegidas - Tipos de reclamo
                .requestMatchers("/api/tiposReclamo/**").hasAuthority("ADMIN")

                // Rutas protegidas - Edificios
                .requestMatchers("/api/edificios/**").hasAuthority("ADMIN")

                // Rutas protegidas - Unidades
                .requestMatchers("/api/unidades/**").hasAuthority("ADMIN")

                // Rutas protegidas - Personas
                .requestMatchers("/api/personas/mis-unidades").hasAuthority("USUARIO")
                .requestMatchers("/api/personas/**").hasAuthority("ADMIN")

                // Rutas protegidas - Imágenes
                .requestMatchers("/api/imagenes/ver/**").hasAnyAuthority("ADMIN", "USUARIO")
                .requestMatchers("/api/imagenes/agregar").hasAuthority("USUARIO")
                .requestMatchers("/api/imagenes/**").hasAuthority("ADMIN")

                // Todo lo demás requiere autenticación
                .anyRequest().authenticated()
            )
            .exceptionHandling().authenticationEntryPoint(jwtAuthenticationEntryPoint)
            .and()
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            .and()
            .addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}


//package com.example.AdministracionEdificiosTpApis.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.http.SessionCreationPolicy;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
//
//import com.example.AdministracionEdificiosTpApis.security.JwtAuthenticationEntryPoint;
//import com.example.AdministracionEdificiosTpApis.security.JwtRequestFilter;
//
//@Configuration
//@EnableWebSecurity
//public class SecurityConfig {
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http, 
//                                           JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint, 
//                                           JwtRequestFilter jwtRequestFilter) throws Exception {
//        http
//            .csrf().disable()
//            .authorizeHttpRequests(auth -> auth
//                // Rutas públicas
//                .requestMatchers("/api/auth/**").permitAll()
//                .requestMatchers("/api/usuario/restablecerContrasena").permitAll()
//
//
//                // Rutas protegidas - Reclamos
//                .requestMatchers("/api/reclamos").hasAuthority("ADMIN")
//                .requestMatchers("/api/reclamos/edificio/**").hasAuthority("ADMIN")
//                .requestMatchers("/api/reclamos/unidad/id/**").hasAuthority("ADMIN")
//                .requestMatchers("/api/reclamos/tipo/**").hasAuthority("ADMIN")
//                .requestMatchers("/api/reclamos/estado/**").hasAuthority("ADMIN")
//                .requestMatchers("/api/reclamos/mis-reclamos").hasAnyAuthority("USUARIO")
//
//                // Rutas protegidas - Tipos de reclamo
//                .requestMatchers("/api/tiposReclamo/**").hasAuthority("ADMIN")
//
//                // Rutas protegidas - Unidades
//                .requestMatchers("/api/unidades").hasAuthority("ADMIN")
//                .requestMatchers("/api/unidades/{id}").hasAuthority("ADMIN")
//                .requestMatchers("/api/unidades/unidad").hasAuthority("ADMIN")
//                .requestMatchers("/api/unidades/{codigo}/duenios").hasAuthority("ADMIN")
//                .requestMatchers("/api/unidades/{codigo}/inquilinos").hasAuthority("ADMIN")
//                .requestMatchers("/api/unidades/{codigo}/transferir").hasAuthority("ADMIN")
//                .requestMatchers("/api/unidades/{codigo}/agregarDuenio").hasAuthority("ADMIN")
//                .requestMatchers("/api/unidades/{codigo}/alquilar").hasAuthority("ADMIN")
//                .requestMatchers("/api/unidades/{codigo}/agregarInquilino").hasAuthority("ADMIN")
//                .requestMatchers("/api/unidades/{codigo}/liberar").hasAuthority("ADMIN")
//                .requestMatchers("/api/unidades/{codigo}/habitar").hasAuthority("ADMIN")
//
//                // Todo lo demás requiere autenticación
//                .anyRequest().authenticated()
//            )
//            .exceptionHandling().authenticationEntryPoint(jwtAuthenticationEntryPoint)
//            .and()
//            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
//            .and()
//            .addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);
//
//        return http.build();
//    }
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder();
//    }
//}
