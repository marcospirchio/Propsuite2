package com.example.AdministracionEdificiosTpApis.exceptions;

public class TipoReclamoException extends Exception{
	
	private static final long serialVersionUID = 22092024L;

	public TipoReclamoException(String mensaje) {
		super(mensaje);
	}
}
