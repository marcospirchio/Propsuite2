package com.example.AdministracionEdificiosTpApis.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.AdministracionEdificiosTpApis.data.PersonaRepository;
import com.example.AdministracionEdificiosTpApis.data.UsuarioDAO;
import com.example.AdministracionEdificiosTpApis.data.UsuarioRepository;
import com.example.AdministracionEdificiosTpApis.exceptions.UsuarioException;
import com.example.AdministracionEdificiosTpApis.model.Persona;
import com.example.AdministracionEdificiosTpApis.model.Usuario;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioDAO usuarioDAO; // DAO personalizado para operaciones avanzadas

    @Autowired
    private UsuarioRepository usuarioRepository; // Repository estándar

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private PersonaRepository personaRepository;
    
    public List<Usuario> obtenerTodosLosUsuarios() {
        return usuarioDAO.getAllUsuarios(); // Método del DAO personalizado
    }

    public Usuario obtenerUsuarioPorId(int id) throws UsuarioException {
        return usuarioDAO.getUsuarioPorId(id) // Método del DAO personalizado
                .orElseThrow(() -> new UsuarioException("Usuario no encontrado."));
    }

    public Usuario obtenerUsuarioPorNombreUsuario(String nombreUsuario) throws UsuarioException {
        return usuarioDAO.getUsuarioPorNombreUsuario(nombreUsuario) // Método del DAO personalizado
                .orElseThrow(() -> new UsuarioException("Usuario no encontrado."));
    }

    public void agregarUsuario(Usuario usuario) {
        // Verificar si la persona asociada existe
        Optional<Persona> personaOptional = personaRepository.findById(usuario.getPersona().getDocumento());
        if (personaOptional.isEmpty()) {
            throw new IllegalArgumentException("La persona con documento " + usuario.getPersona().getDocumento() + " no existe.");
        }

        // Asignar la persona existente
        usuario.setPersona(personaOptional.get());

        // Encriptar la contraseña
        usuario.setContrasena(passwordEncoder.encode(usuario.getContrasena()));

        // Guardar el usuario
        usuarioDAO.agregarUsuario(usuario);
    }


    public void actualizarUsuario(Usuario usuario) throws UsuarioException {
        Usuario usuarioExistente = obtenerUsuarioPorId(usuario.getId()); // Validar que el usuario exista
        usuarioExistente.setContrasena(passwordEncoder.encode(usuario.getContrasena())); // Encriptar contraseña
        usuarioExistente.setRol(usuario.getRol()); // Actualizar rol
        usuarioDAO.actualizarUsuario(usuarioExistente); // Método del DAO personalizado
        System.out.println("Usuario actualizado con éxito.");
    }


    public void eliminarUsuario(int id) throws UsuarioException {
        // Verificar que el usuario exista
        Usuario usuario = obtenerUsuarioPorId(id);

        // Validar que el usuario tiene una persona asociada
        if (usuario.getPersona() == null) {
            throw new UsuarioException("El usuario no tiene una persona asociada.");
        }

        // Log de depuración para verificar datos
        System.out.println("Eliminando usuario con ID: " + id +
                ", Nombre de usuario: " + usuario.getNombreUsuario() +
                ", Documento asociado: " + usuario.getPersona().getDocumento());

        // Eliminar usuario
        usuarioDAO.eliminarUsuario(id);
        System.out.println("Usuario eliminado con éxito.");
    }



    public void restablecerContrasena(String nombreUsuario, String dni, String nuevaContrasena) throws UsuarioException {
        Usuario usuario = usuarioRepository.findByNombreUsuario(nombreUsuario)
                .orElseThrow(() -> new UsuarioException("Nombre de usuario no encontrado."));

        if (!usuario.getPersona().getDocumento().equals(dni)) {
            throw new UsuarioException("El DNI no coincide con el usuario.");
        }

        String contrasenaEncriptada = passwordEncoder.encode(nuevaContrasena);
        usuario.setContrasena(contrasenaEncriptada);
        usuarioRepository.save(usuario);
        System.out.println("Contraseña restablecida correctamente para el usuario: " + nombreUsuario);
    }


}



//package com.example.AdministracionEdificiosTpApis.service;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import com.example.AdministracionEdificiosTpApis.data.UsuarioDAO;
//import com.example.AdministracionEdificiosTpApis.exceptions.UsuarioException;
//import com.example.AdministracionEdificiosTpApis.model.Usuario;
//
//@Service
//public class UsuarioService {
//
//    @Autowired
//    private UsuarioDAO usuarioDAO;
//
//    @Autowired
//    private PasswordEncoder passwordEncoder;
//
//    public List<Usuario> obtenerTodosLosUsuarios() {
//        return usuarioDAO.getAllUsuarios();
//    }
//
//    public Usuario obtenerUsuarioPorId(int id) throws UsuarioException {
//        return usuarioDAO.getUsuarioPorId(id)
//                .orElseThrow(() -> new UsuarioException("Usuario no encontrado."));
//    }
//
//    public Usuario obtenerUsuarioPorNombreUsuario(String nombreUsuario) throws UsuarioException {
//        return usuarioDAO.getUsuarioPorNombreUsuario(nombreUsuario)
//                .orElseThrow(() -> new UsuarioException("Usuario no encontrado."));
//    }
//
//    public void agregarUsuario(Usuario usuario) {
//        // Encriptar la contraseña antes de guardar
//        usuario.setContrasena(passwordEncoder.encode(usuario.getContrasena()));
//        usuarioDAO.agregarUsuario(usuario);
//        System.out.println("Usuario agregado con éxito.");
//    }
//
//    public void actualizarUsuario(Usuario usuario) throws UsuarioException {
//        Usuario usuarioExistente = obtenerUsuarioPorId(usuario.getId());
//        usuarioExistente.setContrasena(passwordEncoder.encode(usuario.getContrasena()));
//        usuarioExistente.setRol(usuario.getRol());
//        usuarioDAO.actualizarUsuario(usuarioExistente);
//        System.out.println("Usuario actualizado con éxito.");
//    }
//
//    public void eliminarUsuario(int id) throws UsuarioException {
//        obtenerUsuarioPorId(id); // Verifica que exista
//        usuarioDAO.eliminarUsuario(id);
//        System.out.println("Usuario eliminado con éxito.");
//    }
//    
//    public void restablecerContrasena(String nombreUsuario, String dni, String nuevaContrasena) throws UsuarioException {
//        Usuario usuario = usuarioDAO.getUsuarioPorNombreUsuario(nombreUsuario)
//                .orElseThrow(() -> new UsuarioException("Nombre de usuario no encontrado."));
//
//        if (!usuario.getDni().equals(dni)) {
//            throw new UsuarioException("El DNI no coincide con el usuario.");
//        }
//
//        String contrasenaEncriptada = passwordEncoder.encode(nuevaContrasena);
//        usuario.setContrasena(contrasenaEncriptada);
//        usuarioDAO.actualizarUsuario(usuario);
//        System.out.println("Contraseña restablecida correctamente para el usuario: " + nombreUsuario);
//    }
//}
