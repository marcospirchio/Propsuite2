package com.example.AdministracionEdificiosTpApis.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.example.AdministracionEdificiosTpApis.exceptions.UsuarioException;
import com.example.AdministracionEdificiosTpApis.model.Usuario;
import com.example.AdministracionEdificiosTpApis.service.UsuarioService;

@RestController
@RequestMapping("/api/usuario")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/restablecerContrasena")
    public ResponseEntity<String> restablecerContrasena(@RequestBody Map<String, String> requestBody) {
        try {
            String nombreUsuario = requestBody.get("nombreUsuario");
            String dni = requestBody.get("dni");
            String nuevaContrasena = requestBody.get("nuevaContrasena");

            if (nombreUsuario == null || dni == null || nuevaContrasena == null) {
                return ResponseEntity.badRequest().body("Faltan campos en la solicitud.");
            }

            usuarioService.restablecerContrasena(nombreUsuario, dni, nuevaContrasena);
            return ResponseEntity.ok("Contraseña restablecida correctamente");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error restableciendo contraseña: " + e.getMessage());
        }
    }
    
    
    @PutMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> actualizarUsuario(@RequestBody Usuario usuario) {
        try {
            usuarioService.actualizarUsuario(usuario);
            return ResponseEntity.ok("Usuario actualizado con éxito.");
        } catch (UsuarioException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al actualizar el usuario.");
        }
    }
    
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> eliminarUsuario(@PathVariable int id) {
        try {
            usuarioService.eliminarUsuario(id);
            return ResponseEntity.ok("Usuario eliminado correctamente.");
        } catch (UsuarioException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al eliminar el usuario.");
        }
    }
    
    
    
}

	

//package com.example.AdministracionEdificiosTpApis.controller;
//
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.example.AdministracionEdificiosTpApis.exceptions.UsuarioException;
//import com.example.AdministracionEdificiosTpApis.service.UsuarioService;
//
//@RestController
//@RequestMapping("/api/usuarios")
//public class UsuarioController {
//
//    @Autowired
//    private UsuarioService usuarioService;
//
//    @PostMapping("/restablecer")
//    public ResponseEntity<String> restablecerContrasena(@RequestBody Map<String, String> datos) {
//        String nombreUsuario = datos.get("nombreUsuario");
//        String dni = datos.get("dni");
//        String nuevaContrasena = datos.get("nuevaContrasena");
//
//        if (nombreUsuario == null || dni == null || nuevaContrasena == null || nuevaContrasena.isEmpty()) {
//            return new ResponseEntity<>("Datos incompletos para restablecer contraseña.", HttpStatus.BAD_REQUEST);
//        }
//        try {
//            usuarioService.restablecerContrasena(nombreUsuario, dni, nuevaContrasena);
//            return new ResponseEntity<>("Contraseña restablecida correctamente.", HttpStatus.OK);
//        } catch (UsuarioException e) {
//            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
//        }
//    }
//
//}
//
