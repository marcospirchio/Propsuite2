package com.example.AdministracionEdificiosTpApis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.example.AdministracionEdificiosTpApis.data.PersonaRepository;
import com.example.AdministracionEdificiosTpApis.exceptions.UsuarioException;
import com.example.AdministracionEdificiosTpApis.model.Persona;
import com.example.AdministracionEdificiosTpApis.model.Usuario;
import com.example.AdministracionEdificiosTpApis.security.JwtTokenUtil;
import com.example.AdministracionEdificiosTpApis.service.UsuarioService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserDetailsService userDetailsService;
    
    @Autowired
    private PersonaRepository personaRepository;
    
    @PostMapping("/registrar")
    public ResponseEntity<String> registrarUsuario(@RequestBody Usuario usuario) {
        usuarioService.agregarUsuario(usuario);
        return ResponseEntity.ok("Usuario registrado con éxito");
    }
//    @PostMapping("/registrar")
//    public ResponseEntity<String> registrarUsuario(@RequestBody Usuario usuario) {
//        if (usuario.getPersona() == null || usuario.getPersona().getDocumento() == null) {
//            return ResponseEntity.badRequest().body("El usuario debe estar asociado a una persona con un documento válido.");
//        }
//
//        Optional<Persona> personaOptional = personaRepository.findById(usuario.getPersona().getDocumento());
//        if (personaOptional.isEmpty()) {
//            return ResponseEntity.badRequest().body("La persona con documento " + usuario.getPersona().getDocumento() + " no existe.");
//        }
//
//        Persona persona = personaOptional.get();
//        usuario.setPersona(persona);
//
//        // Generar y loguear el hash
//        String hashedPassword = passwordEncoder.encode(usuario.getContrasena());
//        System.out.println("Hash generado para la contraseña '" + usuario.getContrasena() + "': " + hashedPassword);
//        usuario.setContrasena(hashedPassword);
//
//        usuarioService.agregarUsuario(usuario);
//
//        return ResponseEntity.ok("Usuario registrado con éxito");
//    }



    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Usuario usuario) throws UsuarioException {
        Usuario user = usuarioService.obtenerUsuarioPorNombreUsuario(usuario.getNombreUsuario());
        System.out.println("Usuario recuperado: " + user);

        if (user != null && passwordEncoder.matches(usuario.getContrasena(), user.getContrasena())) {
            System.out.println("Contraseña validada correctamente.");
            UserDetails userDetails = userDetailsService.loadUserByUsername(usuario.getNombreUsuario());
            final String token = jwtTokenUtil.generateToken(userDetails);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Login exitoso");
            response.put("token", token);
            return ResponseEntity.ok(response);
        }

        System.out.println("Falló la validación de credenciales.");
        return ResponseEntity.badRequest().body("Credenciales inválidas");
    }

//    @PostMapping("/login")
//    public ResponseEntity<?> login(@RequestBody Usuario usuario) throws UsuarioException {
//        Usuario user = usuarioService.obtenerUsuarioPorNombreUsuario(usuario.getNombreUsuario());
//        if (user != null && passwordEncoder.matches(usuario.getContrasena(), user.getContrasena())) {
//            UserDetails userDetails = userDetailsService.loadUserByUsername(usuario.getNombreUsuario());
//            final String token = jwtTokenUtil.generateToken(userDetails);
//            Map<String, Object> response = new HashMap<>();
//            response.put("message", "Login exitoso");
//            response.put("token", token);
//            return ResponseEntity.ok(response);
//        }
//        return ResponseEntity.badRequest().body("Credenciales inválidas");
//    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        SecurityContextHolder.clearContext(); // Cierra la sesión actual.
        return ResponseEntity.ok("Sesión cerrada exitosamente");
    }
}



//package com.example.AdministracionEdificiosTpApis.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.web.bind.annotation.*;
//
//import com.example.AdministracionEdificiosTpApis.exceptions.UsuarioException;
//import com.example.AdministracionEdificiosTpApis.model.Usuario;
//import com.example.AdministracionEdificiosTpApis.service.UsuarioService;
//
//@RestController
//@RequestMapping("/api/auth")
//public class AuthController {
//
//    @Autowired
//    private UsuarioService usuarioService;
//
//    @Autowired
//    private PasswordEncoder passwordEncoder;
//
//    @PostMapping("/registrar")
//    public ResponseEntity<String> registrarUsuario(@RequestBody Usuario usuario) {
//        usuarioService.agregarUsuario(usuario);
//        return ResponseEntity.ok("Usuario registrado con éxito");
//    }
//
//    @PostMapping("/login")
//    public ResponseEntity<String> login(@RequestBody Usuario usuario) throws UsuarioException {
//        Usuario user = usuarioService.obtenerUsuarioPorNombreUsuario(usuario.getNombreUsuario());
//        if (passwordEncoder.matches(usuario.getContrasena(), user.getContrasena())) {
//            return ResponseEntity.ok("Login exitoso");
//        }
//        return ResponseEntity.badRequest().body("Credenciales inválidas");
//    }
//    
//    @PostMapping("/logout")
//    public ResponseEntity<String> logout() {
//        SecurityContextHolder.clearContext(); // Cierra la sesión actual.
//        return ResponseEntity.ok("Sesión cerrada exitosamente");
//    }
//}



