package com.example.AdministracionEdificiosTpApis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.example.AdministracionEdificiosTpApis.service.ImagenService;
import com.example.AdministracionEdificiosTpApis.data.ImagenDAO;
import com.example.AdministracionEdificiosTpApis.exceptions.ImagenException;
import com.example.AdministracionEdificiosTpApis.model.Imagen;

@RestController
@RequestMapping("/api/imagenes")
public class ImagenController {

    @Autowired
    private ImagenService imagenService;

    @Autowired
    private ImagenDAO imagenDAO;

    @GetMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<Imagen>> obtenerTodasLasImagenes() {
        List<Imagen> imagenes = imagenService.obtenerTodasLasImagenes();
        return new ResponseEntity<>(imagenes, HttpStatus.OK);
    }

    @PostMapping("/agregar")
    @PreAuthorize("hasAuthority('USUARIO')")
    public ResponseEntity<String> agregarImagen(
            @RequestParam("archivo") MultipartFile archivo,
            @RequestParam("idReclamo") int idReclamo) throws Exception {

        String contenidoBase64 = Base64.getEncoder().encodeToString(archivo.getBytes());
        imagenService.agregarImagen(archivo.getContentType(), contenidoBase64, idReclamo);

        return new ResponseEntity<>("Imagen cargada y asociada correctamente.", HttpStatus.CREATED);
    }

    @PutMapping("/actualizar/{id}")
    @PreAuthorize("hasAuthority('USUARIO','ADMIN')")
    public ResponseEntity<String> actualizarImagen(
            @PathVariable int id,
            @RequestParam("archivo") MultipartFile archivo) throws Exception {

        // Obtener la imagen existente
        Imagen imagenExistente = imagenService.obtenerImagenPorId(id); // No necesitas orElseThrow si el método ya lanza excepción

        // Convertir el archivo a Base64
        String contenidoBase64 = Base64.getEncoder().encodeToString(archivo.getBytes());

        // Actualizar los datos de la imagen
        imagenExistente.setContenido(contenidoBase64);
        imagenExistente.setTipo(archivo.getContentType());

        // Guardar los cambios
        imagenService.actualizarImagen(imagenExistente);

        return new ResponseEntity<>("Imagen actualizada correctamente.", HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> eliminarImagen(@PathVariable int id) throws ImagenException {
        imagenService.eliminarImagen(id);
        return new ResponseEntity<>("Imagen eliminada correctamente.", HttpStatus.OK);
    }

    @GetMapping("/ver/{id}")
    @PreAuthorize("hasAuthority('ADMIN','USUARIO')")
    public ResponseEntity<byte[]> verImagen(@PathVariable int id) throws ImagenException {
        Imagen imagen = imagenDAO.getImagenById(id)
                .orElseThrow(() -> new ImagenException("Imagen no encontrada."));

        byte[] contenidoImagen = Base64.getDecoder().decode(imagen.getContenido());

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.valueOf(imagen.getTipo()));
        headers.setContentLength(contenidoImagen.length);

        return new ResponseEntity<>(contenidoImagen, headers, HttpStatus.OK);
    }

    @GetMapping("/ver/reclamo/{idReclamo}")
    @PreAuthorize("hasAuthority('ADMIN','USUARIO')")
    public ResponseEntity<List<Map<String, String>>> verImagenesPorReclamo(@PathVariable int idReclamo) throws ImagenException {
        List<Imagen> imagenes = imagenDAO.getImagenesByReclamoId(idReclamo);

        if (imagenes.isEmpty()) {
            throw new ImagenException("No se encontraron imágenes para el reclamo con ID: " + idReclamo);
        }

        List<Map<String, String>> respuesta = new ArrayList<>();
        for (Imagen imagen : imagenes) {
            Map<String, String> imagenData = new HashMap<>();
            imagenData.put("tipo", imagen.getTipo());
            imagenData.put("contenido", "data:" + imagen.getTipo() + ";base64," + imagen.getContenido());
            respuesta.add(imagenData);
        }

        return new ResponseEntity<>(respuesta, HttpStatus.OK);
    }
}
