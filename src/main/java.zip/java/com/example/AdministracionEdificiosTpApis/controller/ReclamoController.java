package com.example.AdministracionEdificiosTpApis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.example.AdministracionEdificiosTpApis.service.ReclamoService;
import com.example.AdministracionEdificiosTpApis.data.ImagenDAO;
import com.example.AdministracionEdificiosTpApis.data.UnidadDAO;
import com.example.AdministracionEdificiosTpApis.data.UsuarioDAO;
import com.example.AdministracionEdificiosTpApis.exceptions.*;
import com.example.AdministracionEdificiosTpApis.model.Usuario;
import com.example.AdministracionEdificiosTpApis.model.Unidad;
import com.example.AdministracionEdificiosTpApis.views.Estado;
import com.example.AdministracionEdificiosTpApis.views.ReclamoView;

import java.util.List;
import java.util.Map;



@RestController
@RequestMapping("/api/reclamos")
public class ReclamoController {

    private final ReclamoService reclamoService;
    private final UsuarioDAO usuarioDAO;
    
    @Autowired
    private UnidadDAO unidadDAO;
    
    @Autowired
    public ReclamoController(ReclamoService reclamoService, UsuarioDAO usuarioDAO) {
        this.reclamoService = reclamoService;
        this.usuarioDAO = usuarioDAO;
    }

    @GetMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<ReclamoView>> obtenerTodosLosReclamos() {
        List<ReclamoView> reclamos = reclamoService.obtenerTodosLosReclamos();
        return new ResponseEntity<>(reclamos, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN', 'USUARIO')")
    public ResponseEntity<ReclamoView> obtenerReclamoPorId(@PathVariable int id) throws ReclamoException {
        ReclamoView reclamo = reclamoService.obtenerReclamoPorId(id);
        return new ResponseEntity<>(reclamo, HttpStatus.OK);
    }


    @GetMapping("/edificio/{codigoEdificio}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<ReclamoView>> obtenerReclamosPorEdificio(@PathVariable int codigoEdificio) throws EdificioException {
        List<ReclamoView> reclamos = reclamoService.obtenerReclamosPorEdificio(codigoEdificio);
        return new ResponseEntity<>(reclamos, HttpStatus.OK);
    }

    @GetMapping("/unidad/{codigoEdificio}/{piso}/{numero}")
    @PreAuthorize("hasAuthority('ADMIN','USUARIO')")
    public ResponseEntity<List<ReclamoView>> obtenerReclamosPorUnidad(
            @PathVariable int codigoEdificio,
            @PathVariable String piso,
            @PathVariable String numero) throws UnidadException {
        List<ReclamoView> reclamos = reclamoService.obtenerReclamosPorUnidad(codigoEdificio, piso, numero);
        return new ResponseEntity<>(reclamos, HttpStatus.OK);
    }

    
    @GetMapping("/unidad/{idUnidad}")
    @PreAuthorize("hasAuthority('ADMIN', 'USUARIO')")
    public ResponseEntity<List<ReclamoView>> obtenerReclamosPorIdUnidad(@PathVariable int idUnidad) throws UnidadException {
        List<ReclamoView> reclamos = reclamoService.obtenerReclamosPorIdUnidad(idUnidad);
        return new ResponseEntity<>(reclamos, HttpStatus.OK);
    }

    @GetMapping("/persona/{documentoPersona}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<ReclamoView>> obtenerReclamosPorPersona(@PathVariable String documentoPersona) throws PersonaException {
        List<ReclamoView> reclamos = reclamoService.obtenerReclamosPorPersona(documentoPersona);
        return new ResponseEntity<>(reclamos, HttpStatus.OK);
    }

    @GetMapping("/tipo/{idTipoReclamo}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<ReclamoView>> obtenerReclamosPorTipo(@PathVariable int idTipoReclamo) {
        List<ReclamoView> reclamos = reclamoService.obtenerReclamosPorTipo(idTipoReclamo);
        return new ResponseEntity<>(reclamos, HttpStatus.OK);
    }

    @GetMapping("/estado/{estado}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<ReclamoView>> obtenerReclamosPorEstado(@PathVariable Estado estado) {
        List<ReclamoView> reclamos = reclamoService.obtenerReclamosPorEstado(estado);
        return new ResponseEntity<>(reclamos, HttpStatus.OK);
    }

    @PostMapping("/conUnidad")
    @PreAuthorize("hasAuthority('USUARIO')")
    public ResponseEntity<Map<String, Object>> agregarReclamoConUnidad(@RequestBody Map<String, Object> request) throws ReclamoException, PersonaException, UnidadException, EdificioException {
        org.springframework.security.core.userdetails.User userDetails =
                (org.springframework.security.core.userdetails.User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        // Obtener el nombre de usuario desde los detalles del usuario autenticado
        String nombreUsuario = userDetails.getUsername();

        // Buscar el usuario en la base de datos para obtener su documento
        Usuario usuario = usuarioDAO.getUsuarioPorNombreUsuario(nombreUsuario)
                .orElseThrow(() -> new PersonaException("Usuario no encontrado en la base de datos."));

        // Extraer el documento de la persona asociada al usuario
        String documentoPersona = usuario.getPersona().getDocumento();

        int codigoEdificio = (int) request.get("codigoEdificio");
        String piso = (String) request.get("piso");
        String numeroUnidad = (String) request.get("numeroUnidad");
        String ubicacion = (String) request.get("ubicacion");
        String descripcion = (String) request.get("descripcion");
        int tipoReclamo = (int) request.get("tipoReclamo");

        // Verificar que el usuario es dueño o inquilino de la unidad y tiene permiso para hacer un reclamo
        Unidad unidad = unidadDAO.getUnidadByCodigoPisoNumero(codigoEdificio, piso, numeroUnidad)
            .orElseThrow(() -> new UnidadException("Unidad no encontrada."));

        boolean isOwner = unidad.getDuenios().stream().anyMatch(persona -> persona.getDocumento().equals(documentoPersona));
        boolean isTenant = unidad.getInquilinos().stream().anyMatch(persona -> persona.getDocumento().equals(documentoPersona));
        boolean isUnoccupied = unidad.getInquilinos().isEmpty();

        if (!(isOwner && (isUnoccupied || !isTenant)) && !isTenant) {
            throw new PersonaException("No autorizado para hacer reclamos en esta unidad.");
        }

        int idReclamo = reclamoService.agregarReclamoConUnidad(codigoEdificio, piso, numeroUnidad, documentoPersona, ubicacion, descripcion, tipoReclamo);

        Map<String, Object> response = Map.of(
                "mensaje", "Reclamo creado exitosamente",
                "idReclamo", idReclamo
        );

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }



    @PostMapping("/sinUnidad")
    @PreAuthorize("hasAuthority('USUARIO')")
    public ResponseEntity<Integer> agregarReclamoSinUnidad(@RequestBody Map<String, Object> request)
            throws ReclamoException, PersonaException, EdificioException, UnidadException {

        // Obtener los detalles del usuario autenticado desde el SecurityContextHolder
        org.springframework.security.core.userdetails.User userDetails =
                (org.springframework.security.core.userdetails.User) SecurityContextHolder.getContext()
                        .getAuthentication()
                        .getPrincipal();

        // Obtener el nombre de usuario desde los detalles del usuario autenticado
        String nombreUsuario = userDetails.getUsername();

        // Buscar el usuario en la base de datos para obtener su documento
        Usuario usuario = usuarioDAO.getUsuarioPorNombreUsuario(nombreUsuario)
                .orElseThrow(() -> new PersonaException("Usuario no encontrado en la base de datos."));

        // Extraer el documento de la persona asociada al usuario
        String documentoPersona = usuario.getPersona().getDocumento();

        int codigoEdificio = (int) request.get("codigoEdificio");
        String ubicacion = (String) request.get("ubicacion");
        String descripcion = (String) request.get("descripcion");
        int tipoReclamo = (int) request.get("tipoReclamo");

        int idReclamo = reclamoService.agregarReclamoSinUnidad(
                codigoEdificio, documentoPersona, ubicacion, descripcion, tipoReclamo
        );

        return new ResponseEntity<>(idReclamo, HttpStatus.CREATED);
    }


    @PutMapping
    @PreAuthorize("hasAuthority('ADMIN','USUARIO')")
    public ResponseEntity<String> actualizarReclamo(@RequestBody Map<String, Object> request) throws ReclamoException {
        int idReclamo = (int) request.get("idReclamo");
        String ubicacion = (String) request.get("ubicacion");
        String descripcion = (String) request.get("descripcion");

        reclamoService.actualizarReclamo(idReclamo, ubicacion, descripcion);
        return new ResponseEntity<>("Reclamo actualizado correctamente.", HttpStatus.OK);
    }

    @PutMapping("/estado")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> cambiarEstadoReclamo(@RequestBody Map<String, Object> request) throws ReclamoException {
        int idReclamo = (int) request.get("idReclamo");
        String estadoStr = (String) request.get("estado");
        String detalleEstado = (String) request.get("detalleEstado"); // Assume it is sent from the client

        // Convert state to enum while ignoring case
        Estado estado = Estado.valueOf(estadoStr.trim().toLowerCase());

        // Update the state of the complaint including the detail
        reclamoService.cambiarEstado(idReclamo, estado, detalleEstado);

        return new ResponseEntity<>("Estado del reclamo actualizado correctamente.", HttpStatus.OK);
    }

    @DeleteMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> eliminarReclamo(@RequestBody Map<String, Object> request) throws ReclamoException {
        int idReclamo = (int) request.get("idReclamo");

        reclamoService.eliminarReclamo(idReclamo);
        return new ResponseEntity<>("Reclamo eliminado correctamente.", HttpStatus.OK);
    }

    @GetMapping("/mis-reclamos")
    @PreAuthorize("hasAnyAuthority('USUARIO')")
    public ResponseEntity<List<ReclamoView>> obtenerMisReclamos() throws PersonaException {
        org.springframework.security.core.userdetails.User userDetails =
                (org.springframework.security.core.userdetails.User) SecurityContextHolder.getContext()
                        .getAuthentication()
                        .getPrincipal();

        String nombreUsuario = userDetails.getUsername();

        Usuario usuario = usuarioDAO.getUsuarioPorNombreUsuario(nombreUsuario)
                .orElseThrow(() -> new PersonaException("Usuario no encontrado en la base de datos."));

        String documento = usuario.getPersona().getDocumento();

        List<ReclamoView> reclamos = reclamoService.obtenerReclamosPorPersona(documento);
        
        return new ResponseEntity<>(reclamos, HttpStatus.OK);
    }

    @GetMapping("/areas-comunes")
    @PreAuthorize("hasAuthority('USUARIO')")
    public ResponseEntity<List<ReclamoView>> obtenerReclamosAreasComunes() throws ReclamoException, PersonaException {
        org.springframework.security.core.userdetails.User userDetails =
                (org.springframework.security.core.userdetails.User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String nombreUsuario = userDetails.getUsername();

        Usuario usuario = usuarioDAO.getUsuarioPorNombreUsuario(nombreUsuario)
                .orElseThrow(() -> new PersonaException("Usuario no encontrado en la base de datos."));

        List<ReclamoView> reclamos = reclamoService.obtenerReclamosAreasComunesPorUsuario(usuario.getPersona().getDocumento());
        return new ResponseEntity<>(reclamos, HttpStatus.OK);
    }

    @GetMapping("/areas-comunes/todos")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<ReclamoView>> obtenerTodosLosReclamosDeAreasComunes() {
        List<ReclamoView> reclamos = reclamoService.obtenerReclamosAreasComunes();
        return new ResponseEntity<>(reclamos, HttpStatus.OK);
    }
}

